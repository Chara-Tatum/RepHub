# RepHub
A hub that provides information on minorities. This resource will help others understand minorities thus allowing for more diverse representation. 
